# CMS-2026-2377-0002 comprehensive evidence package

Snapshot: August 3, 2026, approximately 8:13 PM EDT. The docket remained open.

Coverage: 1,595 public comment detail records and 113 logical attachments. Five image-only attachments were OCR-processed. Theme flags are deterministic, multi-label discovery codes; the 82 direct RPM/RTM employee-only comments received manual stance review.

## Core audit files

- `all_comments_coded.csv`: one row per public comment, public metadata, word counts, attachment count, and all theme flags.
- `all_named_submitters.csv`: complete ranked census of displayed public names and organization-field values.
- `rpm_rtm_comments.csv`: all 99 RPM/RTM-related records, including the 82 direct employee-only comments, stance, subthemes, and short navigation excerpts.
- `duplicate_clusters.csv`: all 75 exact or high-similarity clusters and member IDs.
- `full_corpus_summary.json`: principal corpus, theme, duplication, and RPM/RTM statistics.
- `expanded_metrics.json`: timing, identity, geography, length, theme-intersection, and RPM metadata summaries.

## Expanded exhibits

- `daily_comment_volume.csv`: daily and cumulative filing volume.
- `state_distribution.csv`: all reported state values, including unspecified.
- `category_distribution.csv`: all self-selected public categories.
- `submitter_type_distribution.csv`: individual, organization, and anonymous/withheld record counts.
- `comment_length_distribution.csv`: combined inline-plus-attachment word-count bands.
- `theme_overlap_matrix.csv`: complete pairwise theme overlap matrix.
- `top_theme_intersections.csv`: ranked non-zero theme pairs.
- `theme_by_submitter_type.csv`: theme incidence within each public identity type.
- `organization_submitters.csv`: all distinct public organization-field values.
- `rpm_policy_subthemes.csv`: subtheme counts for the 82 direct RPM/RTM policy comments.
- `rpm_policy_state_distribution.csv`: reported-state distribution for the 82 direct comments.
- `rpm_policy_named_stakeholders.csv`: public named stakeholder map for direct comments.
- `theme_codebook.csv`: operational theme definitions.

## Interpretation cautions

- Theme percentages are multi-label and do not sum to 100%.
- Theme flags measure mentions, not support or opposition.
- Names, organizations, categories, and states are public, self-reported, and incomplete.
- Displayed names are grouped exactly after trimming whitespace; aliases, case variants, abbreviations, and spelling variants are not legally resolved.
- Duplicate-adjusted language units are heuristic and do not establish authorship or coordination.
- This snapshot is descriptive and not necessarily representative of Medicare stakeholders generally.
